# A0-M1-U1-L02 — helper input

SCRIPT ONLY — no audio recording

Read out of the learner's view. This is input, not learner evidence.

1. My name is Anna.
2. Your name is Tom.
3. What is your name?
4. Hello! My name is Tom.
