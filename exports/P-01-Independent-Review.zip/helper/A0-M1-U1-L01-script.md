# A0-M1-U1-L01 — helper input

SCRIPT ONLY — no audio recording

Read out of the learner's view. This is input, not learner evidence.

1. Hello!
2. Goodbye!
3. I am Anna.
4. You are Tom.
