# P-01 — Independent review handoff

**Status: independent review PENDING. This packet was prepared by the author.**
It is not a sign-off, a completed course or a learner test result.

The user has requested the full 624-lesson A0–C1 + IELTS course, but explicitly
chose to KEEP the existing independent-review gate. Only two lessons are
currently authored. Do not write L03/P-02 or substitute outlines for lessons.
All course material must remain English-only. No new lesson is in this packet.

## 1. Use a genuinely fresh reviewer

Open this packet in a separate conversation/session with a reviewer who has
not seen the existing keys, or give it to a different competent person.
The original author, an author reread and deterministic tools do NOT qualify.
A separate context is required; changing a label does not make a fresh review.
This conversation cannot launch a separate independent Arena session itself.

## 2. Blind response phase — FIRST

1. Open only `blind/A0-M1-U1-L01.html` then `blind/A0-M1-U1-L02.html`.
   If HTML was not built, use the matching Markdown files with image preview.
   HTML copies are self-contained: pictures are embedded, with no network,
   JavaScript, external fonts or separate image downloads required.
2. Render/view the pictures. Do not infer visual clarity from SVG code or
   accessibility descriptions alone. The worked examples remain intentionally
   visible: they teach the language. The dedicated answer section (18),
   helper scripts and hidden machine record (21) have been withheld.
   Original numbering and every other learner section are retained.
3. Respond to **all 39 + 47 = 86 prompt IDs** in `forms/BLIND_RESPONSES.csv`.
   Supply your own response/acceptable alternatives and reasoning before keys.
   Do not copy a keyed answer. Record ambiguity and any required untaught
   word, instruction, grammar or unexplained visual convention by location.
4. For listening, a competent helper may read `helper/` out of view as the
   task input. These are four-line SCRIPTS, not recordings. A model reading
   a script can check script/task logic, NOT audition audio or prove listening
   comprehension. Mark unavailable sound/real-learner evidence NOT ASSESSED.
5. Save a dated copy of the completed CSV and its SHA-256 BEFORE opening keys.
   The supplied response cells are intentionally blank reviewer fields;
   they are not missing lesson content or fabricated learner answers.

Do NOT open `sealed/` Markdown/JSON or the author's prior audit/guide in the
blind phase. The SVG image files under `sealed/source/assets/` are safe visual
inputs (also embedded in HTML); the original lesson Markdown is not blind.
This is procedural separation, not cryptographic access control.

## 3. Unblind and audit — SECOND

Open `sealed/source/` for the exact original lessons and their full section-18
keys/rubrics. Open `sealed/P01_LANGUAGE_MANIFEST.json` and
`sealed/P01_DELIVERY_GUIDE.md` only now. Compare EVERY response against the key:
48 closed items need exact independent solves; 38 open items need checked
models, natural variants and observable rubrics. Do not call a reasonable
alternative wrong merely because the author's model differs.

Then use the procedures, database/index snapshots and template in `reference/`
to audit Gates 1–7: English-only; inventory/dependencies; key integrity;
naturalness; pedagogy; zero-English level fit; and honesty. Verify meaning
at the exact point of first use, including headings, visible SVG words,
alt descriptions and all instruction/action conventions. Prior-lesson word
coverage is not the same as taught-before-use coverage or actual retention.

The seven-gate record in `forms/REVIEW_RECORD.md` is UNFILLED. Record per-lesson
findings and a real reviewer identity/session, date, source checksums,
pre-key response hash, commands, inspected images and evidence for each gate.
Do not pre-populate PASS or approve your own packet as independent evidence.

## 4. Return findings, not invented achievements

Return completed forms plus precise fixes for blockers. Reviewer simulation
is not a real beginner trial. No learner scores/mastery, audio intelligibility,
validation or publication may be inferred from successful tools.

No recordings, beginner trials or independent sign-off have been supplied.
Keep both lessons drafted, leave student/ untouched and keep CA-05 open until
real review evidence exists and blocking findings have been repaired.
A reviewer reports findings; the project lead separately decides validation.
F.7 still requires two independent walkthroughs for the WHOLE 12-lesson pilot;
a review of these two drafts does not complete that requirement.

The ZIP's `PACKET_MANIFEST.json` identifies the exact inputs/files. If source
hashes differ, stop and rebuild; never apply a sign-off to changed material.

## 5. Copy this into a NEW independent session

> You are a fresh reviewer, not the author. Review only P-01 lessons
> A0-M1-U1-L01 and A0-M1-U1-L02 using this packet. Follow START_HERE.md in
> order. First inspect the blind student views and actual rendered pictures;
> independently respond to all 86 prompt IDs and save/hash the responses
> BEFORE opening sealed keys or the author's guide/language manifest.
> Record unavailable audio/learner evidence honestly. Then compare all
> answers/alternatives and audit Deliverable D Gates 1–7. Complete the
> review record with source hashes, per-gate evidence and confusion points.
> If you have already seen keys, disclose that and do not claim a blind solve.
> Do not author new lessons, fabricate sign-offs/scores, publish to student/,
> or switch branches. Return findings and fixes for the project lead.
